<?php
session_start();
require_once "../config/database.php";

// Check if admin is logged in


// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $cohort_id = mysqli_real_escape_string($conn, $_POST['cohort_id']);
    
    // Generate unique QR code
    $qr_code = uniqid('CAND_', true);
    
    $query = "INSERT INTO candidates (first_name, last_name, email, cohort_id, qr_code) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sssis", $first_name, $last_name, $email, $cohort_id, $qr_code);
    
    if (mysqli_stmt_execute($stmt)) {
        $success = "Candidate added successfully. QR Code: " . $qr_code;
    } else {
        $error = "Error adding candidate";
    }
}

// Get all cohorts
$cohorts_query = "SELECT * FROM cohorts ORDER BY name";
$cohorts_result = mysqli_query($conn, $cohorts_query);

// Get all candidates with cohort information
$candidates_query = "SELECT c.*, ch.name as cohort_name 
                    FROM candidates c 
                    LEFT JOIN cohorts ch ON c.cohort_id = ch.id 
                    ORDER BY c.created_at DESC";
$candidates_result = mysqli_query($conn, $candidates_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Candidates - QR Sign-In System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .nav-link {
            color: rgba(255,255,255,.8);
        }
        .nav-link:hover {
            color: white;
        }
        .main-content {
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-3">
                <h3 class="text-center mb-4">Admin Panel</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cohorts.php">
                            <i class="fas fa-users"></i> Cohorts
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="candidates.php">
                            <i class="fas fa-user-graduate"></i> Candidates
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="attendance.php">
                            <i class="fas fa-calendar-check"></i> Attendance
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="visitors.php">
                            <i class="fas fa-user-friends"></i> Visitors
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <h2 class="mb-4">Manage Candidates</h2>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <!-- Add Candidate Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Add New Candidate</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="first_name" class="form-label">First Name</label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="last_name" class="form-label">Last Name</label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="cohort_id" class="form-label">Cohort</label>
                                    <select class="form-select" id="cohort_id" name="cohort_id" required>
                                        <option value="">Select Cohort</option>
                                        <?php while ($cohort = mysqli_fetch_assoc($cohorts_result)): ?>
                                            <option value="<?php echo $cohort['id']; ?>">
                                                <?php echo htmlspecialchars($cohort['name']); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Candidate</button>
                        </form>
                    </div>
                </div>
                
                <!-- Candidates List -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Candidates List</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Cohort</th>
                                        <th>QR Code</th>
                                        <th>Created At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($candidate = mysqli_fetch_assoc($candidates_result)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($candidate['first_name'] . ' ' . $candidate['last_name']); ?></td>
                                            <td><?php echo htmlspecialchars($candidate['email']); ?></td>
                                            <td><?php echo htmlspecialchars($candidate['cohort_name']); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-info" onclick="showQRCode('<?php echo $candidate['qr_code']; ?>')">
                                                    View QR Code
                                                </button>
                                            </td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($candidate['created_at'])); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- QR Code Modal -->
    <div class="modal fade" id="qrModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">QR Code</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <div id="qrcode"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script>
        function showQRCode(code) {
            const modal = new bootstrap.Modal(document.getElementById('qrModal'));
            document.getElementById('qrcode').innerHTML = '';
            new QRCode(document.getElementById('qrcode'), {
                text: code,
                width: 256,
                height: 256
            });
            modal.show();
        }
    </script>
</body>
</html> 