<?php
session_start();
require_once "../config/database.php";



// Get cohort ID
$cohort_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($cohort_id > 0) {
    // Get cohort information
    $cohort_query = "SELECT name FROM cohorts WHERE id = ?";
    $cohort_stmt = mysqli_prepare($conn, $cohort_query);
    mysqli_stmt_bind_param($cohort_stmt, "i", $cohort_id);
    mysqli_stmt_execute($cohort_stmt);
    $cohort_result = mysqli_stmt_get_result($cohort_stmt);
    $cohort = mysqli_fetch_assoc($cohort_result);
    
    if ($cohort) {
        // Get all candidates in the cohort with their attendance
        $query = "SELECT 
                    c.first_name,
                    c.last_name,
                    c.email,
                    c.qr_code,
                    GROUP_CONCAT(DATE(a.check_in_time) ORDER BY a.check_in_time) as attendance_dates
                  FROM candidates c
                  LEFT JOIN attendance a ON c.id = a.candidate_id
                  WHERE c.cohort_id = ?
                  GROUP BY c.id
                  ORDER BY c.last_name, c.first_name";
        
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $cohort_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        // Set headers for CSV download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="cohort_' . $cohort['name'] . '_attendance.csv"');
        
        // Create CSV file
        $output = fopen('php://output', 'w');
        
        // Add UTF-8 BOM for proper Excel encoding
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Add headers
        fputcsv($output, ['First Name', 'Last Name', 'Email', 'QR Code', 'Attendance Dates']);
        
        // Add data
        while ($row = mysqli_fetch_assoc($result)) {
            fputcsv($output, [
                $row['first_name'],
                $row['last_name'],
                $row['email'],
                $row['qr_code'],
                $row['attendance_dates'] ? $row['attendance_dates'] : 'No attendance recorded'
            ]);
        }
        
        fclose($output);
        exit();
    }
}

// If we get here, something went wrong
header("Location: cohorts.php?error=1");
exit();
?> 