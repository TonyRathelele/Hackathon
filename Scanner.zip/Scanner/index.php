<?php
session_start();
require_once "config/database.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Sign-In System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .kiosk-container {
            max-width: 800px;
            width: 90%;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .btn-kiosk {
            padding: 2rem;
            margin: 1rem;
            font-size: 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .btn-kiosk:hover {
            transform: translateY(-5px);
        }
        .qr-scanner-container {
            display: none;
            margin-top: 2rem;
        }
        .visitor-form {
            display: none;
            margin-top: 2rem;
        }
        #camera-preview {
            width: 100%;
            max-width: 400px;
            margin: 1rem auto;
        }
    </style>
</head>
<body>
    <div class="kiosk-container text-center">
        <h1 class="mb-4">Welcome to Sign-In System</h1>
        
        <div class="row">
            <div class="col-md-6">
                <button class="btn btn-primary btn-kiosk w-100" onclick="showQRScanner()">
                    <i class="fas fa-qrcode fa-2x mb-2"></i><br>
                    Sign in with QR Code
                </button>
            </div>
            <div class="col-md-6">
                <button class="btn btn-success btn-kiosk w-100" onclick="showVisitorForm()">
                    <i class="fas fa-user-plus fa-2x mb-2"></i><br>
                    Visitor Sign-In
                </button>
            </div>
        </div>

        <div id="qr-scanner-container" class="qr-scanner-container">
            <h3>Scan your QR Code</h3>
            <div id="reader"></div>
        </div>

        <div id="visitor-form" class="visitor-form">
            <h3>Visitor Information</h3>
            <form id="visitor-signin-form" action="process_visitor.php" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <input type="text" class="form-control" name="first_name" placeholder="First Name" required>
                </div>
                <div class="mb-3">
                    <input type="text" class="form-control" name="last_name" placeholder="Last Name" required>
                </div>
                <div class="mb-3">
                    <input type="text" class="form-control" name="id_number" placeholder="ID Number" required>
                </div>
                <div class="mb-3">
                    <video id="camera-preview" autoplay></video>
                    <input type="hidden" name="photo_data" id="photo-data">
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
            </form>
        </div>
    </div>

    <script src="https://unpkg.com/html5-qrcode"></script>
    <script>
        function showQRScanner() {
            document.getElementById('qr-scanner-container').style.display = 'block';
            document.getElementById('visitor-form').style.display = 'none';
            
            const html5QrcodeScanner = new Html5QrcodeScanner(
                "reader", { fps: 10, qrbox: 250 });
            
            html5QrcodeScanner.render((decodedText) => {
                // Handle the scanned code
                fetch('process_qr.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ qr_code: decodedText })
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if(data.success) {
                        html5QrcodeScanner.clear();
                    }
                });
            });
        }

        function showVisitorForm() {
            document.getElementById('visitor-form').style.display = 'block';
            document.getElementById('qr-scanner-container').style.display = 'none';
            
            // Initialize camera
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    document.getElementById('camera-preview').srcObject = stream;
                })
                .catch(err => console.error(err));
        }

        // Capture photo when form is submitted
        document.getElementById('visitor-signin-form').onsubmit = function(e) {
            e.preventDefault();
            const video = document.getElementById('camera-preview');
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            document.getElementById('photo-data').value = canvas.toDataURL('image/jpeg');
            this.submit();
        };
    </script>
</body>
</html> 