<?php
require_once "config/database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $id_number = mysqli_real_escape_string($conn, $_POST['id_number']);
    $photo_data = $_POST['photo_data'];
    
    // Create uploads directory if it doesn't exist
    $upload_dir = "uploads/visitors/";
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Save the photo
    $photo_name = time() . '_' . $id_number . '.jpg';
    $photo_path = $upload_dir . $photo_name;
    
    // Convert base64 image to file
    $photo_data = str_replace('data:image/jpeg;base64,', '', $photo_data);
    $photo_data = str_replace(' ', '+', $photo_data);
    $photo_data = base64_decode($photo_data);
    file_put_contents($photo_path, $photo_data);
    
    // Insert visitor record
    $query = "INSERT INTO visitors (first_name, last_name, id_number, photo_path) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssss", $first_name, $last_name, $id_number, $photo_path);
    
    if (mysqli_stmt_execute($stmt)) {
        header("Location: index.php?success=1");
    } else {
        header("Location: index.php?error=1");
    }
    exit();
}
?> 