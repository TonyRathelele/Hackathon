<?php
session_start();
require_once "config/database.php";

// Get success/error messages
$success = isset($_GET['success']) ? $_GET['success'] : null;
$error = isset($_GET['error']) ? $_GET['error'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Sign-In System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .main-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: #fff;
            border-bottom: none;
            border-radius: 15px 15px 0 0 !important;
            padding: 1.5rem;
        }
        .card-body {
            padding: 2rem;
        }
        .btn-primary {
            background: #4e73df;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
        }
        .btn-primary:hover {
            background: #2e59d9;
        }
        .btn-outline-primary {
            border-color: #4e73df;
            color: #4e73df;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
        }
        .btn-outline-primary:hover {
            background: #4e73df;
            color: white;
        }
        .qr-scanner-container {
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            position: relative;
        }
        #qr-reader {
            width: 100% !important;
            border-radius: 10px;
            overflow: hidden;
        }
        .camera-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border: 2px solid #4e73df;
            border-radius: 10px;
            pointer-events: none;
        }
        .visitor-form {
            max-width: 500px;
            margin: 0 auto;
        }
        .form-control {
            border-radius: 8px;
            padding: 0.8rem;
            border: 1px solid #e3e6f0;
        }
        .form-control:focus {
            border-color: #4e73df;
            box-shadow: 0 0 0 0.2rem rgba(78,115,223,0.25);
        }
        .nav-tabs {
            border: none;
            margin-bottom: 2rem;
        }
        .nav-tabs .nav-link {
            border: none;
            color: #6c757d;
            font-weight: 600;
            padding: 1rem 2rem;
            border-radius: 8px;
            margin-right: 0.5rem;
        }
        .nav-tabs .nav-link.active {
            background: #4e73df;
            color: white;
        }
        .nav-tabs .nav-link:hover:not(.active) {
            background: #f8f9fc;
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .alert-success {
            background: #e3fcef;
            color: #0a3622;
        }
        .alert-danger {
            background: #fce3e3;
            color: #360a0a;
        }
        .photo-preview {
            width: 200px;
            height: 200px;
            border-radius: 10px;
            object-fit: cover;
            margin: 1rem auto;
            display: none;
        }
        .camera-container {
            position: relative;
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
        }
        #camera-preview {
            width: 100%;
            border-radius: 10px;
            display: none;
        }
        .camera-controls {
            margin-top: 1rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="text-center mb-5">
            <h1 class="display-4 mb-3">Welcome to QR Sign-In</h1>
            <p class="lead text-muted">Please choose your sign-in method below</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $success == 1 ? 'Sign-in successful!' : $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $error == 1 ? 'An error occurred. Please try again.' : $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <ul class="nav nav-tabs justify-content-center" id="signInTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="qr-tab" data-bs-toggle="tab" data-bs-target="#qr" type="button" role="tab">
                    <i class="fas fa-qrcode me-2"></i>QR Code Sign-In
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="visitor-tab" data-bs-toggle="tab" data-bs-target="#visitor" type="button" role="tab">
                    <i class="fas fa-user me-2"></i>Visitor Sign-In
                </button>
            </li>
        </ul>

        <div class="tab-content">
            <!-- QR Code Tab -->
            <div class="tab-pane fade show active" id="qr" role="tabpanel">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">Scan QR Code</h4>
                    </div>
                    <div class="card-body text-center">
                        <div class="qr-scanner-container">
                            <div id="qr-reader"></div>
                            <div class="camera-overlay"></div>
                        </div>
                        <p class="text-muted mt-3">Position the QR code within the frame to scan</p>
                    </div>
                </div>
            </div>

            <!-- Visitor Tab -->
            <div class="tab-pane fade" id="visitor" role="tabpanel">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">Visitor Sign-In</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="process_visitor.php" class="visitor-form">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="first_name" class="form-label">First Name</label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="last_name" class="form-label">Last Name</label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="id_number" class="form-label">ID Number</label>
                                <input type="text" class="form-control" id="id_number" name="id_number" required>
                            </div>
                            <div class="mb-4">
                                <label class="form-label">Photo</label>
                                <div class="camera-container">
                                    <video id="camera-preview" autoplay playsinline></video>
                                    <img id="photo-preview" class="photo-preview" alt="Photo Preview">
                                    <div class="camera-controls">
                                        <button type="button" class="btn btn-outline-primary me-2" id="start-camera">
                                            <i class="fas fa-camera me-2"></i>Start Camera
                                        </button>
                                        <button type="button" class="btn btn-primary" id="capture-photo">
                                            <i class="fas fa-camera-retro me-2"></i>Take Photo
                                        </button>
                                    </div>
                                </div>
                                <input type="hidden" name="photo_data" id="photo-data">
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-sign-in-alt me-2"></i>Sign In
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script>
        // QR Code Scanner
        function onScanSuccess(decodedText, decodedResult) {
            // Stop scanning
            html5QrcodeScanner.stop();
            
            // Send QR code to server
            fetch('process_qr.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    qr_code: decodedText
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Restart scanner
                    html5QrcodeScanner.start();
                } else {
                    alert(data.message);
                    // Restart scanner
                    html5QrcodeScanner.start();
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
                // Restart scanner
                html5QrcodeScanner.start();
            });
        }

        const html5QrcodeScanner = new Html5QrcodeScanner(
            "qr-reader", { fps: 10, qrbox: 250 }
        );
        html5QrcodeScanner.render(onScanSuccess);

        // Camera and Photo Capture
        let stream = null;
        const video = document.getElementById('camera-preview');
        const photoPreview = document.getElementById('photo-preview');
        const startButton = document.getElementById('start-camera');
        const captureButton = document.getElementById('capture-photo');
        const photoData = document.getElementById('photo-data');

        startButton.addEventListener('click', async () => {
            try {
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: { 
                        facingMode: 'user',
                        width: { ideal: 1280 },
                        height: { ideal: 720 }
                    } 
                });
                video.srcObject = stream;
                video.style.display = 'block';
                photoPreview.style.display = 'none';
                startButton.disabled = true;
                captureButton.disabled = false;
            } catch (err) {
                console.error('Error accessing camera:', err);
                alert('Error accessing camera. Please make sure you have granted camera permissions.');
            }
        });

        captureButton.addEventListener('click', () => {
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            
            // Convert to base64
            const imageData = canvas.toDataURL('image/jpeg');
            photoData.value = imageData;
            
            // Show preview
            photoPreview.src = imageData;
            photoPreview.style.display = 'block';
            video.style.display = 'none';
            
            // Stop camera
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
            
            // Reset buttons
            startButton.disabled = false;
            captureButton.disabled = true;
        });

        // Handle tab changes
        document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', (e) => {
                if (e.target.id === 'qr-tab') {
                    html5QrcodeScanner.start();
                } else {
                    html5QrcodeScanner.stop();
                }
            });
        });
    </script>
</body>
</html> 