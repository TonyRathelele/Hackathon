<?php
session_start();
require_once "../config/database.php";



// Get filter parameters
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$cohort_id = isset($_GET['cohort_id']) ? (int)$_GET['cohort_id'] : 0;

// Get all cohorts for filter
$cohorts_query = "SELECT * FROM cohorts ORDER BY name";
$cohorts_result = mysqli_query($conn, $cohorts_query);

// Build attendance query
$query = "SELECT 
            a.id,
            a.check_in_time,
            a.location,
            c.first_name,
            c.last_name,
            c.email,
            ch.name as cohort_name
          FROM attendance a
          JOIN candidates c ON a.candidate_id = c.id
          LEFT JOIN cohorts ch ON c.cohort_id = ch.id
          WHERE DATE(a.check_in_time) = ?";

if ($cohort_id > 0) {
    $query .= " AND c.cohort_id = ?";
}

$query .= " ORDER BY a.check_in_time DESC";

$stmt = mysqli_prepare($conn, $query);

if ($cohort_id > 0) {
    mysqli_stmt_bind_param($stmt, "si", $date, $cohort_id);
} else {
    mysqli_stmt_bind_param($stmt, "s", $date);
}

mysqli_stmt_execute($stmt);
$attendance_result = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - QR Sign-In System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .nav-link {
            color: rgba(255,255,255,.8);
        }
        .nav-link:hover {
            color: white;
        }
        .main-content {
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-3">
                <h3 class="text-center mb-4">Admin Panel</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cohorts.php">
                            <i class="fas fa-users"></i> Cohorts
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="candidates.php">
                            <i class="fas fa-user-graduate"></i> Candidates
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="attendance.php">
                            <i class="fas fa-calendar-check"></i> Attendance
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="visitors.php">
                            <i class="fas fa-user-friends"></i> Visitors
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <h2 class="mb-4">Attendance Records</h2>
                
                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="row g-3">
                            <div class="col-md-4">
                                <label for="date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="date" name="date" value="<?php echo $date; ?>">
                            </div>
                            <div class="col-md-4">
                                <label for="cohort_id" class="form-label">Cohort</label>
                                <select class="form-select" id="cohort_id" name="cohort_id">
                                    <option value="">All Cohorts</option>
                                    <?php while ($cohort = mysqli_fetch_assoc($cohorts_result)): ?>
                                        <option value="<?php echo $cohort['id']; ?>" <?php echo $cohort_id == $cohort['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($cohort['name']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">&nbsp;</label>
                                <button type="submit" class="btn btn-primary d-block">Apply Filters</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Attendance List -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Attendance Records for <?php echo date('F j, Y', strtotime($date)); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Cohort</th>
                                        <th>Location</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($record = mysqli_fetch_assoc($attendance_result)): ?>
                                        <tr>
                                            <td><?php echo date('H:i:s', strtotime($record['check_in_time'])); ?></td>
                                            <td><?php echo htmlspecialchars($record['first_name'] . ' ' . $record['last_name']); ?></td>
                                            <td><?php echo htmlspecialchars($record['email']); ?></td>
                                            <td><?php echo htmlspecialchars($record['cohort_name']); ?></td>
                                            <td><?php echo htmlspecialchars($record['location']); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 