<?php
session_start();
require_once "../config/database.php";

// Check if admin is logged in

if (isset($_POST['cohort_id'])) {
    $cohort_id = (int)$_POST['cohort_id'];
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // First delete attendance records for candidates in this cohort
        $delete_attendance = "DELETE a FROM attendance a 
                            JOIN candidates c ON a.candidate_id = c.id 
                            WHERE c.cohort_id = ?";
        $stmt = mysqli_prepare($conn, $delete_attendance);
        mysqli_stmt_bind_param($stmt, "i", $cohort_id);
        mysqli_stmt_execute($stmt);
        
        // Then delete candidates in this cohort
        $delete_candidates = "DELETE FROM candidates WHERE cohort_id = ?";
        $stmt = mysqli_prepare($conn, $delete_candidates);
        mysqli_stmt_bind_param($stmt, "i", $cohort_id);
        mysqli_stmt_execute($stmt);
        
        // Finally delete the cohort
        $delete_cohort = "DELETE FROM cohorts WHERE id = ?";
        $stmt = mysqli_prepare($conn, $delete_cohort);
        mysqli_stmt_bind_param($stmt, "i", $cohort_id);
        mysqli_stmt_execute($stmt);
        
        // Commit transaction
        mysqli_commit($conn);
        header("Location: cohorts.php?success=deleted");
    } catch (Exception $e) {
        // Rollback transaction on error
        mysqli_rollback($conn);
        header("Location: cohorts.php?error=delete_failed");
    }
} else {
    header("Location: cohorts.php");
}
exit();
?> 