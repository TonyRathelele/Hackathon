<?php
session_start();
require_once "../config/database.php";

// Check if admin is logged in


if (isset($_POST['candidate_id'])) {
    $candidate_id = (int)$_POST['candidate_id'];
    
    // First delete attendance records
    $delete_attendance = "DELETE FROM attendance WHERE candidate_id = ?";
    $stmt = mysqli_prepare($conn, $delete_attendance);
    mysqli_stmt_bind_param($stmt, "i", $candidate_id);
    mysqli_stmt_execute($stmt);
    
    // Then delete the candidate
    $delete_candidate = "DELETE FROM candidates WHERE id = ?";
    $stmt = mysqli_prepare($conn, $delete_candidate);
    mysqli_stmt_bind_param($stmt, "i", $candidate_id);
    
    if (mysqli_stmt_execute($stmt)) {
        header("Location: candidates.php?success=deleted");
    } else {
        header("Location: candidates.php?error=delete_failed");
    }
} else {
    header("Location: candidates.php");
}
exit();
?> 