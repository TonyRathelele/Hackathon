<?php
require_once "config/database.php";

header('Content-Type: application/json');

// Get the JSON data
$data = json_decode(file_get_contents('php://input'), true);
$qr_code = mysqli_real_escape_string($conn, $data['qr_code']);

// Get candidate information
$query = "SELECT id, first_name, last_name FROM candidates WHERE qr_code = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $qr_code);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($candidate = mysqli_fetch_assoc($result)) {
    // Check if already signed in today
    $today = date('Y-m-d');
    $check_query = "SELECT id FROM attendance WHERE candidate_id = ? AND DATE(check_in_time) = ?";
    $check_stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($check_stmt, "is", $candidate['id'], $today);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($check_result) > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'You have already signed in today'
        ]);
        exit();
    }
    
    // Record attendance
    $insert_query = "INSERT INTO attendance (candidate_id, location) VALUES (?, ?)";
    $insert_stmt = mysqli_prepare($conn, $insert_query);
    $location = "QR Code Sign-in"; // You can enhance this with actual location data
    mysqli_stmt_bind_param($insert_stmt, "is", $candidate['id'], $location);
    
    if (mysqli_stmt_execute($insert_stmt)) {
        echo json_encode([
            'success' => true,
            'message' => 'Welcome ' . $candidate['first_name'] . '! Sign-in successful.'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error recording attendance'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid QR code'
    ]);
}
?> 